/*
Product Name: dhtmlxCombo 
Version: 4.6 
Edition: Standard 
License: content of this file is covered by GPL. Usage outside GPL terms is prohibited. To obtain Commercial or Enterprise license contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/
window.dhtmlxAjax={get:function(o,t,n){return n?dhx4.ajax.getSync(o):void dhx4.ajax.get(o,t)},post:function(o,t,n,e){return e?dhx4.ajax.postSync(o,t):void dhx4.ajax.post(o,t,n)},getSync:function(o){return dhx4.ajax.getSync(o)},postSync:function(o,t){return dhx4.ajax.postSync(o,t)}},dhtmlXCombo.prototype.loadXML=function(o,t){this.load(o,t)},dhtmlXCombo.prototype.loadXMLString=function(o){this.load(o)},dhtmlXCombo.prototype.enableOptionAutoHeight=function(){},dhtmlXCombo.prototype.enableOptionAutoPositioning=function(){},dhtmlXCombo.prototype.enableOptionAutoWidth=function(){},dhtmlXCombo.prototype.destructor=function(){this.unload()},dhtmlXCombo.prototype.render=function(){},dhtmlXCombo.prototype.setOptionHeight=function(){},dhtmlXCombo.prototype.attachChildCombo=function(){},dhtmlXCombo.prototype.setAutoSubCombo=function(){};